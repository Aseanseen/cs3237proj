/*
 * Copyright (c) 2016, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *    ======== i2ctmp007.c ========
 */

/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/knl/Task.h>

/* TI-RTOS Header files */
#include <ti/drivers/PIN.h>
#include <ti/drivers/I2C.h>


/* TI-RTOS Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/PWM.h>


/* Example/Board Header files */
#include "Board.h"
#include "SensorOpt3001.h"
#include "SensorHdc1000.h"
#include "SensorUtil.h"
#include "SensorI2C.h"
#include "SensorMpu9250.h"
#include <ti/sysbios/knl/Semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <ti/drivers/PWM.h>

#define TASKSTACKSIZE       2048
#define TMP007_OBJ_TEMP     0x0003  /* Object Temp Result Register */
UInt32 sleepTickCount;
float result_mpu;
float result_opt;

/*
 * Application LED pin configuration table:
 *   - All LEDs board LEDs are off.
 */
PIN_Config ledPinTable[] = {
Board_LED1 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
                             Board_LED2 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW
                                     | PIN_PUSHPULL | PIN_DRVSTR_MAX,
                             PIN_TERMINATE };

/*
 *  ======== echoFxn ========
 *  Task for this function is created statically. See the project's .cfg file.
 */
#define HDC1000_REG_TEMP           0x00 // Temperature
#define HDC1000_REG_HUM            0x01 // Humidity
#define HDC1000_REG_CONFIG         0x02 // Configuration
#define HDC1000_REG_SERID_H        0xFB // Serial ID high
#define HDC1000_REG_SERID_M        0xFC // Serial ID middle
#define HDC1000_REG_SERID_L        0xFD // Serial ID low
#define HDC1000_REG_MANF_ID        0xFE // Manufacturer ID
#define HDC1000_REG_DEV_ID         0xFF // Device ID

// Fixed values
#define HDC1000_VAL_MANF_ID        0x5449
#define HDC1000_VAL_DEV_ID         0x1000
#define HDC1000_VAL_CONFIG         0x1000 // 14 bit, acquired in sequence

#define SENSOR_DESELECT()   SensorI2C_deselect()

Task_Struct task1Struct, task2Struct, task3Struct;
Char task1Stack[TASKSTACKSIZE], task2Stack[TASKSTACKSIZE], task3Stack[TASKSTACKSIZE];
Semaphore_Struct semStruct;
Semaphore_Handle semHandle;

PWM_Handle pwm1;


void setUpOpt3001() {
    // config sensor
    SensorOpt3001_init();
    SensorOpt3001_enable(true);
    if (!SensorOpt3001_test())
    {
        System_printf("SensorOpt3001 did not pass test!\n");
    }
}

bool readOPT3001(uint16_t* rawdata, unsigned int i)
{


    // read data
    
    // CS3237 TODO: add code to read optical sensor data. The API is provided in OPT3001 library code

    if (SensorOpt3001_read(rawdata))
    {

        *rawdata = SensorOpt3001_convert(*rawdata);
        //System_printf("SensorOpt3001 Sample  %u: %d \n", i, *rawdata);
        //CS3237 TODO: please add code to convert data. API provided in OPT3001 library code.
        // ...
        System_flush();
        return true;
    }
    else
    {
        System_printf("SensorOpt3001 I2C fault!\n");
        System_flush();
        return false;
    }
    
}

void setUpMpu9250()
{
    // config MPU
    SensorMpu9250_powerOn();
    if (!SensorMpu9250_init())
    {
        System_printf("SensorMPU9250_ cannot init!\n");
        return;
    }
    SensorMpu9250_accSetRange(ACC_RANGE_2G);
    SensorMpu9250_enable(9);
    SensorMpu9250_enableWom(1);
    if (!SensorMpu9250_test())
    {
        System_printf("SensorMPU9250_ did not pass test!\n");
    }
}


bool readMpu9250(float* rawdata, unsigned int i)
{
    char str[80];

    // read MPU data
    uint16_t rawdata_raw;
    //CS3237 TODO: add code to read MPU accelermoter data. The API is provided in MPU library code.
    if (SensorMpu9250_accRead(&rawdata_raw))
    {
        //System_printf("SensorMPU9250_ no.Sample %u: %d (C)\n", i, rawdata_raw);
        // No need to convert
        *rawdata = SensorMpu9250_accConvert(rawdata_raw);
        sprintf(str, "%f", *rawdata);
//            System_printf("SensorMPU9250_ no.Sample %u: %d (C)\n", i, *rawdata);
        //System_printf("SensorMPU9250_ no.Sample %u: %s (C)\n", i, str);

        // See if conversion is necessary
        //....
        System_flush();
        return true;
    }
    else
    {
        System_printf("SensorMPU9250_ I2C fault!\n");
        System_flush();
        return false;
    }
        
}

void setUpPwm() 
{
    PWM_Params params;
    uint16_t   pwmPeriod = 3000;      // Period and duty in microseconds

    PWM_Params_init(&params);
    params.dutyUnits = PWM_DUTY_US;
    params.dutyValue = 0;
    params.periodUnits = PWM_PERIOD_US;
    params.periodValue = pwmPeriod;
    pwm1 = PWM_open(Board_PWM0, &params);
    if (pwm1 == NULL) {
        System_abort("Board_PWM0 did not open");
    }
    PWM_start(pwm1);
}

void setPwmLed(float pwmFactor)
{
    uint16_t   pwmPeriod = 3000;      // Period and duty in microseconds
    uint16_t   duty;

    if (pwmFactor < 0 || pwmFactor > 1) {
        System_printf("Invalid paramaters given!");
        pwmFactor = 0.5;
    }

    duty = (uint16_t)(pwmFactor * pwmPeriod);

    PWM_setDuty(pwm1, duty);
}

// You need to write the task functions here.

void read_opt_task() {
    char str[80];

    uint16_t rawdata;
    float result;
    int i = 1;
    setUpOpt3001();
    for(;;) {

        // for (i = 1; i < 5; i++) {
        // if (Semaphore_getCount(semHandle) == 0) {
        //     System_printf("Sem blocked in opt\n\n");
        // } else {
        //     System_printf("Sem taken in opt\n\n");
        // }

        Semaphore_pend(semHandle, BIOS_WAIT_FOREVER);

        if (readOPT3001(&rawdata, i)) i++;
        result += (float) rawdata;
        
        Task_sleep(sleepTickCount);
        if (i > 10) {

            i = 1;
            
            result = result / 10;
            sprintf(str, "%f", result);
            System_printf("raw OPT: %s\n\n", str);
            result = result / 2000;
            result_opt = (result > 1 ? 1 : result < 0 ? 0 : result);

            sprintf(str, "%f", result);
            System_printf("OPT: %s\n\n", str);

            setPwmLed(result_opt > result_mpu ? result_opt : result_mpu);
            result = 0;
        }
        Semaphore_post(semHandle);
    }
}



void read_mpu_task() {
    char str[80];

    float rawdata;
    float result;
    int i = 1;
    setUpMpu9250();
    for(;;) {

        // if (Semaphore_getCount(semHandle) == 0) {
        //     System_printf("Sem blocked in mpu\n\n");
        // } else {
        //     System_printf("Sem taken in mpu\n\n");
        // }

        Semaphore_pend(semHandle, BIOS_WAIT_FOREVER);

        if (readMpu9250(&rawdata, i)) i++;
        result += rawdata;

        Task_sleep(sleepTickCount);
        if (i > 10) {

            i = 1;

            result = result < 0 ? -result : result;
            result = result / 10;
            result = (result - 0.3) / (1.2 - 0.3);
            result_mpu = (result > 1 ? 1 : result < 0 ? 0 : result);

            sprintf(str, "%f", result);
            System_printf("MPU: %s\n\n", str);

            setPwmLed(result_opt > result_mpu ? result_opt : result_mpu);
            result = 0;
        }

        Semaphore_post(semHandle);

        // Task_sleep(sleepTickCount*5);
    }
}



/*
 *  ======== main ========
 */
int main(void)
{
    /* Call board init functions */
    Board_initGeneral();
    Board_initI2C();
    Board_initGPIO();
    Board_initPWM();

    GPIO_write(Board_LED0, Board_LED_ON);

    setUpPwm();
    // CS3237 TODO: Create task structures for reading sensor data and performing PWM. Do not forgot to open I2C, which is available in the library file SensorI2C.c.
    if (!SensorI2C_open())
    {
        System_abort("I2C did not open");
    }

    /* Construct writer/reader Task threads */
    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = TASKSTACKSIZE;
    taskParams.stack = &task1Stack;
    taskParams.priority = 2;
    Task_construct(&task1Struct, (Task_FuncPtr)read_mpu_task, &taskParams, NULL);

    taskParams.stack = &task2Stack;
    taskParams.priority = 1;
    Task_construct(&task2Struct, (Task_FuncPtr)read_opt_task, &taskParams, NULL);

    /* Construct a Semaphore object to be use as a resource lock, inital count 1 */
    Semaphore_Params semParams;
    Semaphore_Params_init(&semParams);
    Semaphore_construct(&semStruct, 1, &semParams);
    
    /* Obtain instance handle */
    semHandle = Semaphore_handle(&semStruct);

    /* We want to sleep for 10000 microseconds */
    sleepTickCount = 10000 / Clock_tickPeriod;

    // CS3237 new tip: It might happen that you get I2C fault or some weird data in the first read. You can get right data if you read sensor again.

    System_printf("Starting the I2C example\nSystem provider is set to SysMin."
                  " Halt the target to view any SysMin contents in ROV.\n");



    /* SysMin will only print to the console when you call flush or exit */
    System_flush();

    /* Start BIOS */
    BIOS_start();

    return (0);
}
